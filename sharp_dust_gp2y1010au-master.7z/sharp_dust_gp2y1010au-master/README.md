# Arduino library for Sharp GP2Y1010AU sensor

This is a very simple library for Sharp GP2Y1010AU dust sensor.

base code is from the following page. :
http://www.dfrobot.com/wiki/index.php/Sharp_GP2Y1010AU

# How to Install

1. Download the library source
1. In the Arduino IDE, go to the Sketch -> Import Library... -> Add Library...
1. Find the directory that contains the sharp\_dust\_gp2y1010au library source, and open it
1. Check if you could see "sharp\_dust\_gp2y1010au" under Sketch -> Import Library...
